import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The demo ships as `npm run build` + FastAPI serving front/dist on one port (8090).
// The dev server below is a convenience path only: it needs its own registered
// port (8082 is a dev-range candidate in PORTS.md) and proxies /api to the API.
export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: 8082,
    strictPort: true,
    proxy: { '/api': { target: 'http://127.0.0.1:8090', changeOrigin: true } }
  },
  build: { outDir: 'dist', emptyOutDir: true }
})
