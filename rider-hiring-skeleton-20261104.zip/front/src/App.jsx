import React, { useEffect, useState } from 'react'
import {
  Alert, Button, Card, Col, Form, Input, InputNumber, Layout, Modal,
  Row, Select, Space, Statistic, Table, Tag, message
} from 'antd'

const { Header, Content } = Layout

const STATUS_COLOR = {
  submitted: 'blue', screening: 'geekblue', interview: 'orange',
  offered: 'gold', hired: 'green', rejected: 'red'
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  })
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`)
  return res.json()
}

export default function App() {
  const [health, setHealth] = useState(null)
  const [riders, setRiders] = useState({ items: [], total: 0 })
  const [apps, setApps] = useState([])
  const [open, setOpen] = useState(false)
  const [form] = Form.useForm()

  const load = async () => {
    try {
      const [h, r, a] = await Promise.all([
        api('/api/health'),
        api('/api/v1/riders?limit=20'),
        api('/api/v1/applications')
      ])
      setHealth(h); setRiders(r); setApps(a)
    } catch (e) {
      message.error(`加载失败：${e.message}`)
    }
  }

  useEffect(() => { load() }, [])

  const create = async () => {
    const values = await form.validateFields()
    try {
      await api('/api/v1/riders', { method: 'POST', body: JSON.stringify(values) })
      message.success('已创建')
      setOpen(false); form.resetFields(); load()
    } catch (e) { message.error(`创建失败：${e.message}`) }
  }

  const move = async (row, target) => {
    try {
      await api(`/api/v1/applications/${row.id}/transition`,
        { method: 'POST', body: JSON.stringify({ target }) })
      message.success(`#${row.id} → ${target}`); load()
    } catch (e) { message.error(`流转失败：${e.message}`) }
  }

  return (
    <Layout>
      <Header style={{ background: '#001529', color: '#fff', fontSize: 18 }}>
        骑手招聘 · 通用骨架（演示数据，全部合成）
      </Header>
      <Content style={{ padding: 24 }}>
        {health && (
          <Alert type="success" showIcon style={{ marginBottom: 16 }}
            message={`服务正常 · DB=${health.db} · 骑手 ${health.riders} 人 · 运行 ${health.uptime_s}s`} />
        )}
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={8}><Card><Statistic title="骑手总数" value={riders.total} /></Card></Col>
          <Col span={8}><Card><Statistic title="投递总数" value={apps.length} /></Card></Col>
          <Col span={8}><Card><Statistic title="已入职" value={apps.filter(a => a.status === 'hired').length} /></Card></Col>
        </Row>
        <Card title="骑手档案" extra={<Button type="primary" onClick={() => setOpen(true)}>新增骑手</Button>}
          style={{ marginBottom: 16 }}>
          <Table rowKey="id" size="small" dataSource={riders.items} pagination={false}
            columns={[
              { title: 'ID', dataIndex: 'id', width: 60 },
              { title: '姓名', dataIndex: 'name' },
              { title: '手机', dataIndex: 'phone' },
              { title: '城市', dataIndex: 'city' },
              { title: '车辆', dataIndex: 'vehicle' },
              { title: '经验(年)', dataIndex: 'years_experience', width: 90 }
            ]} />
        </Card>
        <Card title="投递进展（状态机）">
          <Table rowKey="id" size="small" dataSource={apps}
            columns={[
              { title: 'ID', dataIndex: 'id', width: 60 },
              { title: '骑手ID', dataIndex: 'rider_id', width: 80 },
              { title: '岗位', dataIndex: 'posting' },
              { title: '状态', dataIndex: 'status', render: s => <Tag color={STATUS_COLOR[s]}>{s}</Tag> },
              {
                title: '操作', render: (_, row) => (
                  <Space>
                    <Button size="small" onClick={() => move(row, 'screening')}>筛选</Button>
                    <Button size="small" onClick={() => move(row, 'interview')}>面试</Button>
                    <Button size="small" onClick={() => move(row, 'offered')}>发offer</Button>
                    <Button size="small" type="primary" onClick={() => move(row, 'hired')}>入职</Button>
                  </Space>
                )
              }
            ]} />
        </Card>
      </Content>
      <Modal title="新增骑手" open={open} onOk={create} onCancel={() => setOpen(false)} okText="创建">
        <Form form={form} layout="vertical" initialValues={{ vehicle: 'ebike', years_experience: 1, city: '上海' }}>
          <Form.Item name="name" label="姓名" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="phone" label="手机（唯一）" rules={[{ required: true, min: 5 }]}><Input /></Form.Item>
          <Form.Item name="city" label="城市" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="vehicle" label="车辆">
            <Select options={['ebike', 'bike', 'car', 'walk'].map(v => ({ value: v, label: v }))} />
          </Form.Item>
          <Form.Item name="years_experience" label="经验（年）"><InputNumber min={0} max={40} /></Form.Item>
        </Form>
      </Modal>
    </Layout>
  )
}
