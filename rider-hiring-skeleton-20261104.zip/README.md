# 骑手招聘系列 · 通用骨架

ClawHunt 1804–1808（任务 1/5–5/5）同批标的的复用骨架。任一条中标即可套用：
FastAPI + SQLite/PostgreSQL 可切换 + React/AntD + 状态机 + docker compose + 自动 OpenAPI。

**所有演示数据都是合成的**（见 `back/app/seed_data.py` 每行 `note="合成数据-演示用"`），不含任何客户私有数据。

## 目录

```
rider-hiring-skeleton/
├─ back/                     FastAPI 后端
│  ├─ app/
│  │  ├─ main.py            入口、生命周期建表+播种、健康检查、静态挂载
│  │  ├─ api.py             骑手/投递/状态流转 5 个 REST 端点
│  │  ├─ db.py              DATABASE_URL 切换 SQLite ↔ PostgreSQL
│  │  ├─ models.py          Rider / Application 两张表
│  │  ├─ schemas.py         Pydantic 模型（自动生成 OpenAPI）
│  │  ├─ state_machine.py   submitted→screening→interview→offered→hired
│  │  └─ seed_data.py       12 条合成骑手 + 6 条投递
│  ├─ seed.py               种子脚本（--reset 可清库重灌）
│  ├─ tests/smoke_e2e.py    端到端冒烟（7 项断言，stdlib urllib）
│  └─ requirements.txt
├─ front/                    React 18 + AntD 5 + Vite
│  ├─ src/App.jsx           健康横幅 + 骑手表 + 投递状态机表 + 新增表单
│  └─ vite.config.js
├─ Dockerfile                多阶段：前端构建 → 单镜像同时出 API 与静态页
├─ docker-compose.yml        SQLite 默认；`--profile pg` 切 PostgreSQL
└─ DELIVERY-PLAYBOOK.md      中标后 D1–D4 交付清单（复用件）
```

## 前置条件

- Python ≥ 3.10（用 `python -V` 自查）
- 不需要任何 key / token：默认 SQLite，数据全部是合成数据
- 首次启动会自动建表并播种（12 名骑手 + 6 条投递）
- 服务监听 `127.0.0.1:8090`，启动前先确认该端口空闲
- 下面所有命令都在 `back/` 目录下执行

## 三步跑起来（整段复制）

```bash
cd back
pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8090
```

打开 http://127.0.0.1:8090/ 就是完整页面（健康横幅 + 12 名合成骑手 + 6 条投递）；
`/docs` 是自动生成的接口文档；`/openapi.json` 是机器可读契约。

要重新灌数据：`python seed.py --reset`。

## 换成 PostgreSQL

```bash
pip install "psycopg[binary]"
export DATABASE_URL=postgresql+psycopg://riders:riders@127.0.0.1:5432/riders
python -m uvicorn app.main:app --host 127.0.0.1 --port 8090
```

代码里没有第二处读数据库地址，切库只改这一个环境变量。

## 冒烟测试

服务起来后：

```bash
python tests/smoke_e2e.py --base http://127.0.0.1:8090
```

覆盖：健康检查、列表、创建、重复手机号 409、投递、合法流转、非法流转 409、OpenAPI 生成。

## docker compose

```bash
docker compose up --build                  # SQLite
docker compose --profile pg up --build     # PostgreSQL
```

端口固定 `127.0.0.1:8090`，故意不写自动递增，避免和本机其它服务抢端口。
