"""Request/response models. Pydantic turns these into the OpenAPI schema."""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Status = Literal["submitted", "screening", "interview", "offered", "hired", "rejected"]


class RiderIn(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    phone: str = Field(min_length=5, max_length=32)
    city: str = Field(min_length=1, max_length=32)
    vehicle: Literal["ebike", "bike", "car", "walk"] = "ebike"
    years_experience: int = Field(default=0, ge=0, le=40)
    note: str | None = None


class RiderOut(RiderIn):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime


class RiderPage(BaseModel):
    items: list[RiderOut]
    total: int
    limit: int
    offset: int


class ApplicationIn(BaseModel):
    rider_id: int
    posting: str = Field(min_length=1, max_length=64)
    note: str | None = None


class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    rider_id: int
    posting: str
    status: str
    created_at: datetime
    updated_at: datetime


class TransitionIn(BaseModel):
    target: Status
