"""Application status machine. One table, no hidden transitions.

Deliberately boring: adding a state means adding one row here and one test.
"""
from __future__ import annotations

STATUSES = ("submitted", "screening", "interview", "offered", "hired", "rejected")

FLOW: dict[str, tuple[str, ...]] = {
    "submitted": ("screening", "rejected"),
    "screening": ("interview", "rejected"),
    "interview": ("offered", "rejected"),
    "offered": ("hired", "rejected"),
    "hired": (),
    "rejected": (),
}


def allowed(status: str) -> tuple[str, ...]:
    return FLOW.get(status, ())


def check(current: str, target: str) -> None:
    """Raise ValueError with a readable message for an illegal move."""
    if current not in FLOW:
        raise ValueError(f"unknown status {current!r}")
    if target not in FLOW[current]:
        raise ValueError(
            f"illegal transition {current!r} -> {target!r}; allowed: {list(FLOW[current])}"
        )
