"""Database wiring: SQLite by default, PostgreSQL by setting DATABASE_URL.

Both paths go through the same SQLAlchemy engine, so switching is one env var:

    DATABASE_URL=sqlite:///./data/app.db          # default (zero install)
    DATABASE_URL=postgresql+psycopg://user:pass@db:5432/riders

Nothing else in the code reads the URL.
"""
from __future__ import annotations

import os
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./data/app.db")
_IS_SQLITE = DATABASE_URL.startswith("sqlite")

if _IS_SQLITE:
    # Site-packages lookups aside, the sqlite file needs a real directory.
    Path(DATABASE_URL.replace("sqlite:///", "")).parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if _IS_SQLITE else {},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def db_kind() -> str:
    return "sqlite" if _IS_SQLITE else "postgresql"
