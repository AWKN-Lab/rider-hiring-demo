"""REST endpoints: health is in main.py; everything else lives here."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import models, schemas, state_machine
from .db import SessionLocal

router = APIRouter(prefix="/api/v1")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/riders", response_model=schemas.RiderPage)
def list_riders(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    city: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    stmt = select(models.Rider)
    if city:
        stmt = stmt.where(models.Rider.city == city)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(models.Rider.id).offset(offset).limit(limit)).all()
    return {"items": rows, "total": total, "limit": limit, "offset": offset}


@router.post("/riders", response_model=schemas.RiderOut, status_code=201)
def create_rider(payload: schemas.RiderIn, db: Session = Depends(get_db)):
    dup = db.scalar(select(models.Rider).where(models.Rider.phone == payload.phone))
    if dup:
        raise HTTPException(status_code=409, detail=f"phone {payload.phone} already exists")
    rider = models.Rider(**payload.model_dump())
    db.add(rider)
    db.commit()
    db.refresh(rider)
    return rider


@router.get("/applications", response_model=list[schemas.ApplicationOut])
def list_applications(
    status: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    stmt = select(models.Application)
    if status:
        stmt = stmt.where(models.Application.status == status)
    return db.scalars(stmt.order_by(models.Application.id)).all()


@router.post("/applications", response_model=schemas.ApplicationOut, status_code=201)
def create_application(payload: schemas.ApplicationIn, db: Session = Depends(get_db)):
    if not db.get(models.Rider, payload.rider_id):
        raise HTTPException(status_code=404, detail=f"rider {payload.rider_id} not found")
    app_row = models.Application(**payload.model_dump())
    db.add(app_row)
    db.commit()
    db.refresh(app_row)
    return app_row


@router.post("/applications/{app_id}/transition", response_model=schemas.ApplicationOut)
def transition(app_id: int, payload: schemas.TransitionIn, db: Session = Depends(get_db)):
    row = db.get(models.Application, app_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"application {app_id} not found")
    try:
        state_machine.check(row.status, payload.target)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    row.status = payload.target
    db.commit()
    db.refresh(row)
    return row


@router.get("/applications/{app_id}/next")
def next_states(app_id: int, db: Session = Depends(get_db)):
    row = db.get(models.Application, app_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"application {app_id} not found")
    return {"id": app_id, "status": row.status, "allowed": list(state_machine.allowed(row.status))}
