"""Synthetic demo data. Every value here is invented for the demo; no client data.

Kept separate from main.py so `python seed.py` and the startup hook use the same rows.
"""
from __future__ import annotations

DEMO_RIDERS = [
    {"name": "林小北", "phone": "13800000001", "city": "上海", "vehicle": "ebike",
     "years_experience": 3, "note": "合成数据-演示用"},
    {"name": "周小南", "phone": "13800000002", "city": "上海", "vehicle": "ebike",
     "years_experience": 1, "note": "合成数据-演示用"},
    {"name": "吴小东", "phone": "13800000003", "city": "上海", "vehicle": "bike",
     "years_experience": 2, "note": "合成数据-演示用"},
    {"name": "郑小西", "phone": "13800000004", "city": "北京", "vehicle": "ebike",
     "years_experience": 5, "note": "合成数据-演示用"},
    {"name": "王小满", "phone": "13800000005", "city": "北京", "vehicle": "car",
     "years_experience": 4, "note": "合成数据-演示用"},
    {"name": "陈小奇", "phone": "13800000006", "city": "广州", "vehicle": "ebike",
     "years_experience": 0, "note": "合成数据-演示用"},
    {"name": "赵小双", "phone": "13800000007", "city": "广州", "vehicle": "ebike",
     "years_experience": 2, "note": "合成数据-演示用"},
    {"name": "孙小乐", "phone": "13800000008", "city": "深圳", "vehicle": "bike",
     "years_experience": 1, "note": "合成数据-演示用"},
    {"name": "钱小虎", "phone": "13800000009", "city": "深圳", "vehicle": "ebike",
     "years_experience": 6, "note": "合成数据-演示用"},
    {"name": "李小白", "phone": "13800000010", "city": "杭州", "vehicle": "ebike",
     "years_experience": 3, "note": "合成数据-演示用"},
    {"name": "冯小丁", "phone": "13800000011", "city": "杭州", "vehicle": "walk",
     "years_experience": 0, "note": "合成数据-演示用"},
    {"name": "何小六", "phone": "13800000012", "city": "成都", "vehicle": "ebike",
     "years_experience": 4, "note": "合成数据-演示用"},
]

DEMO_POSTINGS = ("骑手招募-上海站", "骑手招募-北京站", "骑手招募-华南站")


def seed(session, rider_model, application_model) -> tuple[int, int]:
    """Insert demo rows only when the pool is empty; safe to call on every boot."""
    existing = session.query(rider_model).count()
    if existing:
        return 0, 0
    riders = [rider_model(**row) for row in DEMO_RIDERS]
    session.add_all(riders)
    session.commit()
    for rider, posting in zip(riders[:6], DEMO_POSTINGS * 2):
        session.add(application_model(rider_id=rider.id, posting=posting))
    session.commit()
    return len(riders), 6
