"""FastAPI entry point.

Run it:
    cd back && python -m uvicorn app.main:app --host 127.0.0.1 --port 8090
OpenAPI:  http://127.0.0.1:8090/openapi.json
Docs:     http://127.0.0.1:8090/docs
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select

from . import models
from .api import router
from .db import Base, SessionLocal, db_kind, engine
from .seed_data import seed

STARTED_AT = time.time()
FRONT_DIST = Path(__file__).resolve().parents[2] / "front" / "dist"


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as session:
        seed(session, models.Rider, models.Application)
    yield


app = FastAPI(
    title="Rider Hiring Skeleton",
    version="0.1.0",
    description="Reusable skeleton for the rider-recruitment series. Demo data only.",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8090", "http://localhost:8090"],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)


@app.get("/api/health", tags=["ops"])
def health():
    with SessionLocal() as session:
        riders = len(session.scalars(select(models.Rider)).all())
    return {
        "status": "ok",
        "db": db_kind(),
        "riders": riders,
        "uptime_s": round(time.time() - STARTED_AT, 1),
        "time_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


# Built frontend (npm run build) is served from the same process, so one port
# covers the whole demo. Absent before the first build -- that is fine.
if FRONT_DIST.exists():
    app.mount("/", StaticFiles(directory=str(FRONT_DIST), html=True), name="front")
