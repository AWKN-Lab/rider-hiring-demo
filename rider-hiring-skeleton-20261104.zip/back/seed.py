"""Standalone seed CLI.

    python seed.py            # insert demo rows if the pool is empty
    python seed.py --reset    # drop all rows first, then reseed

Synthetic data only -- see app/seed_data.py.
"""
from __future__ import annotations

import argparse

from app import models
from app.db import Base, SessionLocal, engine
from app.seed_data import seed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true", help="delete every row first")
    args = parser.parse_args()

    Base.metadata.create_all(engine)
    with SessionLocal() as session:
        if args.reset:
            session.query(models.Application).delete()
            session.query(models.Rider).delete()
            session.commit()
        riders, applications = seed(session, models.Rider, models.Application)
        total_riders = session.query(models.Rider).count()
        total_apps = session.query(models.Application).count()
    print(f"SEED riders_added={riders} applications_added={applications} "
          f"total_riders={total_riders} total_applications={total_apps}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
