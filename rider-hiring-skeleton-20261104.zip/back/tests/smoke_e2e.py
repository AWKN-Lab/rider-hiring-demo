"""End-to-end smoke test against a running server.

    python tests/smoke_e2e.py --base http://127.0.0.1:8090

Exit code 0 = every check passed. Uses only the stdlib so it can run on any box.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request

PASS, FAIL = "PASS", "FAIL"
results: list[tuple[str, str, str]] = []


def call(base: str, method: str, path: str, body: dict | None = None,
         expect: int = 200) -> tuple[int, dict]:
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(
        f"{base}{path}", data=data, method=method,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            status, payload = resp.status, resp.read().decode()
    except urllib.error.HTTPError as exc:
        status, payload = exc.code, exc.read().decode()
    try:
        parsed = json.loads(payload) if payload else {}
    except json.JSONDecodeError:
        parsed = {"raw": payload}
    verdict = PASS if status == expect else FAIL
    results.append((verdict, f"{method} {path}", f"http={status} expect={expect}"))
    return status, parsed


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8090")
    args = ap.parse_args()
    base = args.base.rstrip("/")

    # 1. health
    status, body = call(base, "GET", "/api/health")
    ok_health = status == 200 and body.get("status") == "ok"
    results[-1] = (PASS if ok_health else FAIL, "GET /api/health", f"http={status} db={body.get('db')}")

    # 2. list
    status, body = call(base, "GET", "/api/v1/riders?limit=5")
    ok_list = status == 200 and body.get("total", 0) > 0 and len(body.get("items", [])) > 0
    results[-1] = (PASS if ok_list else FAIL, "GET /api/v1/riders",
                   f"http={status} total={body.get('total')} page={len(body.get('items', []))}")

    # 3. create (unique phone per run so reruns do not 409)
    stamp = str(int(time.time()))
    payload = {"name": f"冒烟骑手{stamp[-4:]}", "phone": f"139{stamp[-8:]}",
               "city": "上海", "vehicle": "ebike", "years_experience": 1,
               "note": "smoke-test synthetic"}
    status, body = call(base, "POST", "/api/v1/riders", payload, expect=201)
    ok_create = status == 201 and body.get("id")
    results[-1] = (PASS if ok_create else FAIL, "POST /api/v1/riders",
                   f"http={status} id={body.get('id')} phone={body.get('phone')}")

    # 4. apply + legal transition + illegal transition (409)
    if ok_create:
        status, app_row = call(base, "POST", "/api/v1/applications",
                               {"rider_id": body["id"], "posting": "骑手招募-上海站"}, expect=201)
        ok_app = status == 201 and app_row.get("status") == "submitted"
        results[-1] = (PASS if ok_app else FAIL, "POST /api/v1/applications",
                       f"http={status} id={app_row.get('id')} status={app_row.get('status')}")

        status, moved = call(base, "POST", f"/api/v1/applications/{app_row['id']}/transition",
                             {"target": "screening"})
        results[-1] = (PASS if status == 200 and moved.get("status") == "screening" else FAIL,
                       "POST /api/v1/applications/{id}/transition",
                       f"http={status} status={moved.get('status')}")

        status, blocked = call(base, "POST", f"/api/v1/applications/{app_row['id']}/transition",
                               {"target": "hired"}, expect=409)
        results[-1] = (PASS if status == 409 else FAIL,
                       "POST /transition illegal (screening->hired)",
                       f"http={status} detail={str(blocked.get('detail'))[:60]}")

    # 5. OpenAPI is generated
    status, _ = call(base, "GET", "/openapi.json")
    results[-1] = (PASS if status == 200 else FAIL, "GET /openapi.json", f"http={status}")

    width = max(len(name) for _, name, _ in results)
    for verdict, name, detail in results:
        print(f"{verdict:4}  {name:<{width}}  {detail}")
    failed = [r for r in results if r[0] == FAIL]
    print(f"\nSMOKE {'PASS' if not failed else 'FAIL'} {len(results) - len(failed)}/{len(results)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
